<?php $__env->startSection("content"); ?>


        <a href="<?php echo e(route('posts.create')); ?>"><button class="btn btn-primary">create</button></a>
        <a href="<?php echo e(route('posts.restore')); ?>"><i class="fas-solid fas-arrow-rotate-left mt-5"></i></a>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">title</th>
                    <th scope="col">desc</th>
                    <th scope="col">posted_by</th>
                    <th scope="col">created_at</th>
                    <th scope="col">action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($post['id']); ?></th>
                        <td><?php echo e($post['title']); ?></td>
                        <td><?php echo e($post['description']); ?></td>
                        <td><?php echo e($post->user ? $post->user->name : "can't be Found"); ?></td>
                        <td>  <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y')); ?> </td>
                        <td>


                
                     

                            <form method="POST" action="<?php echo e(route('posts.destroy' , [$post['id']])); ?>">
                                <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <a href="<?php echo e(route('posts.show', [$post['id']])); ?>">
                                <button type="button" class="btn btn-primary">View</button>

                            </a>

                            

                            <a href="<?php echo e(route('posts.edit' , $post->id)); ?>">
                              <button type="button" class="btn btn-success">Edit</button>
                            </a>
                                    <button type="submit" class="btn btn-danger delete" data-confirm="Are you sure to delete this item?">Delete</button>


                                            </form>


                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($posts->links()); ?>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/laravel_lab1/AtaAlla-ibrahim-laravel-lab1/resources/views/posts/index.blade.php ENDPATH**/ ?>