<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('post.update', $post->id)); ?>" >
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
      <label class="form-label">title</label>
      <input type="text" class="form-control" name="title" value="<?php echo e($post->title); ?>">
    </div>
    <div class="mb-3">
      <label  class="form-label">desc</label>
      <textarea name="desc" id="" cols="30" rows="10" class="form-control"><?php echo e($post->description); ?></textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">creator</label>
        <select name="creator" id=""class="form-control" >
            <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </select>
      </div>
    <button type="submit" class="btn btn-primary">EDIT</button>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/laravel_lab1/AtaAlla-ibrahim-laravel-lab1/resources/views/posts/edit.blade.php ENDPATH**/ ?>