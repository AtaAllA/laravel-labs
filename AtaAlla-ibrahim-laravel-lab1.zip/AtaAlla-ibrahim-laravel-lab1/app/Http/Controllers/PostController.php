<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use Carbon\Carbon;

class PostController extends Controller
{
    public function index()
    {
        
        
        $posts = post::paginate(5);
        // $post=DB::table('posts')->paginate(2);
        return view('posts.index', [
            'posts' => $posts,
        ]);
    }

    

    public function show($postId)
    {
//        dd($postId);
 


       // $posts = Post::where('id',$postId)->frist();
       $post= post::find($postId);

       return view('posts.show', ['post' => $post]);

        

    }


    public function create()
    {
        $Users=User::all();

        return view('posts.create' , [
            'Users' => $Users,
        ]);
    }


    public function store(Request $request){

        //frist Sol

        // $data = request()->all();
        // $title = $data['title'];
        // $description = $data['description'];
        // $postCreator = $data['post_creator'];


        // Second Sol: 
        // $title = request()->title;
        // $description = requeest()->description;
        // $postCreator = request()->postCreator;
        
        //Third sol: type hinting :


         $data = request()->all();

        $title = $data['title'];
        $description = $data['description'];
        $postCreator = $data['post_creator'];
        
        //dd($title , $description , $postCreator);

        Post::create([
            'title' => $title,
            'postCreator' => $post_creator,
            'description' => $description,
        ]);

        //return view('posts.store');
         return redirect()->route('posts.index');


}



    public function edit($postId){
        
        $post= post::findOrFail($postId);
        // dd($postId);
        $Users=User::all();
    
        return view('posts.edit', ['post' => $post,'Users' => $Users,
    ]);



    }

    public function update($postId , Request $request){
        $post= post::findOrFail($postId);
        $data = $request->all();
            // dd($data);
            $title = $data['title'];
            $description = $data['description'];
        $postCreator = $data['post_creator'];

        $post->update([
            'title'=>$title,
            'description'=>$description,
            'user_Id'=>$postCreator,
    
    
        ]);
        return redirect(route('posts'));
    
    
    }

    
    public function destroy($postId){

        post::findOrfail($postId)->delete();
        return redirect('/posts');
        // $post->restore();;
    }

    public function restore(){
        $posts=post::withTrashed()->restore();

        return redirect('/posts');


    }

}
